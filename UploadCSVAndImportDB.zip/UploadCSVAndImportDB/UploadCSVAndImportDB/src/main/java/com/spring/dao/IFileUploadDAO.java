package com.spring.dao;

import java.util.Collection;
import java.util.List;

import com.spring.entity.AccumulativeDeal;
import com.spring.entity.InValidDeal;
import com.spring.entity.ValidDeal;

public interface IFileUploadDAO {
	
	    boolean fileExists(String fileName);
	    
	    public <T extends ValidDeal> Collection<T> bulkValidSave(Collection<T> entities, List<AccumulativeDeal> accumulativeDeals);
	    
	    public <T extends InValidDeal> Collection<T> bulkInvalidSave(Collection<T> entities);

}
