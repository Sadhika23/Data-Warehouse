package com.spring.service;

import java.util.List;

import com.spring.entity.CSVRecord;
import com.spring.entity.DealModel;
import com.spring.entity.ValidDeal;
/**
 * @author Sadhika
 *
 */
public interface IFileUploadService {

	void saveValidData(List<CSVRecord> dealDetails);
	
	void saveInValidData(List<CSVRecord> dealDetails);
	
	boolean checkFileExist(String fileName);

}
